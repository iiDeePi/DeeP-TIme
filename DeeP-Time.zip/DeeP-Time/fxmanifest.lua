fx_version 'cerulean'
game 'gta5'

author 'DeeP'
description 'DeeP Date & Time'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/DeeP-style.css',
    'html/DeeP-script.js'
}

client_script 'client.lua'
